class UserNotFound(Exception):
  pass

class ProjectNotFound(Exception):
  pass

class StudioNotFound(Exception):
  pass

class PostNotFound(Exception):
  pass

class TopicNotFound(Exception):
  pass

class PageNotFound(Exception):
  pass
