from ScraGet.forum import get_post, get_topic
from ScraGet.project import get_project
from ScraGet.studios import get_studio
from ScraGet.user import get_user, get_user_extra
from ScraGet.frontpage import get_frontpage

#this is a file to make using this package easier.