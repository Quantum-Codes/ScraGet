from ScraGet.forum import get_post, get_topic
from ScraGet.project import get_project
from ScraGet.studios import get_studio
from ScraGet.user import get_user, get_user_extra
from ScraGet.frontpage import get_frontpage
from ScraGet import ScraGet

print("ScraGet: https://github.com/Quantum-Codes/ScraGet")